﻿@extends('layouts.layout', ['title' => 'Kontak'])

@section('content')
<section class="bg-[#0b1f3a] px-5 py-16 text-white lg:px-8">
    <div class="mx-auto max-w-7xl">
        <p class="text-sm font-bold uppercase tracking-widest text-yellow-300">Mari berdiskusi</p>
        <h1 class="mt-3 text-4xl font-black sm:text-5xl">Hubungi Kami</h1>
        <p class="mt-5 max-w-2xl text-lg leading-8 text-slate-300">Ceritakan kebutuhan gas industri atau instalasi Anda kepada tim kami.</p>
    </div>
</section>

<section class="mx-auto grid max-w-7xl gap-10 px-5 py-16 lg:grid-cols-2 lg:px-8">
    <div class="rounded-2xl bg-white p-6 shadow-sm sm:p-8">
        <h2 class="text-2xl font-black text-[#0b1f3a]">Kirim pesan</h2>

        @if (session('success'))
            <div class="mt-5 rounded-lg bg-green-50 p-4 text-sm text-green-700">{{ session('success') }}</div>
        @endif

        @if ($errors->any())
            <div class="mt-5 rounded-lg bg-red-50 p-4 text-sm text-red-700">Mohon periksa kembali data yang Anda isi.</div>
        @endif

        <form action="{{ route('contact.submit') }}" method="POST" class="mt-6 space-y-5">
            @csrf
            <div>
                <label for="name" class="mb-2 block text-sm font-bold">Nama</label>
                <input id="name" name="name" value="{{ old('name') }}" required class="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100">
            </div>
            <div>
                <label for="phone" class="mb-2 block text-sm font-bold">No HP</label>
                <input id="phone" name="phone" type="tel" value="{{ old('phone') }}" required class="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100">
            </div>
            <div>
                <label for="message" class="mb-2 block text-sm font-bold">Pesan</label>
                <textarea id="message" name="message" rows="5" required class="w-full rounded-lg border border-slate-300 px-4 py-3 outline-none focus:border-red-600 focus:ring-2 focus:ring-red-100">{{ old('message') }}</textarea>
            </div>
            <button class="w-full rounded-lg bg-yellow-400 px-5 py-3 font-extrabold text-[#0b1f3a] transition hover:bg-yellow-300">Kirim Pesan</button>
        </form>
    </div>

    <div>
        <div class="rounded-2xl bg-slate-100 p-6 sm:p-8">
            <h2 class="text-2xl font-black text-[#0b1f3a]">Informasi kontak</h2>
            <div class="mt-6 space-y-4 text-slate-600">
                <p><strong class="text-[#0b1f3a]">Telepon</strong><br>+62 812-0000-0000</p>
                <p><strong class="text-[#0b1f3a]">Email</strong><br>info@jayagasindo.com</p>
                <p><strong class="text-[#0b1f3a]">Jam operasional</strong><br>Senin–Sabtu, 08.00–17.00 WIB</p>
            </div>
        </div>
        <div class="mt-6 overflow-hidden rounded-2xl bg-slate-200">
            <iframe title="Lokasi MG Jaya Gasindo" src="https://www.google.com/maps?q=Jakarta%20Indonesia&output=embed" class="h-72 w-full border-0" loading="lazy"></iframe>
        </div>
    </div>
</section>
@endsection