@extends('layouts.admin')

@section('title', 'Detail '.$po->pono)

@section('content')
    <div class="space-y-6">
        <section class="flex flex-col justify-between gap-5 rounded-[1.75rem] bg-[#0b1f3a] px-6 py-8 text-white shadow-xl shadow-[#0b1f3a]/15 sm:flex-row sm:items-end sm:px-9">
            <div>
                <a href="{{ route('admin.po.index') }}" class="inline-flex min-h-11 items-center font-bold text-yellow-300 underline decoration-yellow-300 decoration-2 underline-offset-4 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-yellow-300">Kembali ke daftar PO</a>
                <p class="mt-5 text-sm font-bold uppercase tracking-[0.16em] text-yellow-300">Detail Purchase Order</p>
                <h1 class="mt-3 break-words text-3xl font-black sm:text-5xl">{{ $po->pono }}</h1>
                <p class="mt-3 text-sm text-slate-300">Quotation asal: {{ $po->quotation?->nomor_quotation ?? 'Tidak tersedia' }}</p>
            </div>
            <div class="flex flex-wrap gap-3">
                <span class="inline-flex min-h-11 items-center rounded-full px-4 py-2 text-sm font-black {{ $po->status_class }}">{{ $po->label_status }}</span>
                <button type="button" disabled class="inline-flex min-h-11 items-center rounded-lg border border-white/20 px-4 text-sm font-bold text-slate-400" title="Fitur cetak PDF belum tersedia">Cetak PDF - Menyusul</button>
            </div>
        </section>

        <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Data ringkas PO">
            <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p class="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Customer</p><p class="mt-3 font-black text-[#0b1f3a]">{{ $po->customer?->nama_pt ?? '-' }}</p><p class="mt-1 text-xs text-slate-500">{{ $po->idcust }}</p></div>
            <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p class="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Tanggal order</p><p class="mt-3 font-black text-[#0b1f3a]">{{ $po->tgl_order?->translatedFormat('d F Y') }}</p></div>
            <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p class="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">Jadwal pengiriman</p><p class="mt-3 font-black text-[#0b1f3a]">{{ $po->schedule_delivery?->translatedFormat('d F Y') }}</p></div>
            <div class="rounded-2xl border border-yellow-200 bg-yellow-50 p-5 shadow-sm"><p class="text-xs font-bold uppercase tracking-[0.12em] text-yellow-900">Total PO</p><p class="mt-3 text-xl font-black text-[#0b1f3a]">Rp {{ number_format((float) $po->total, 0, ',', '.') }}</p></div>
        </section>

        @if ($po->isEditable())
            <section class="flex flex-wrap gap-3 rounded-2xl border border-yellow-200 bg-yellow-50 p-5" aria-label="Aksi PO draft">
                <a href="{{ route('admin.po.edit', $po) }}" class="inline-flex min-h-11 items-center rounded-lg bg-[#0b1f3a] px-5 text-sm font-bold text-white transition hover:bg-[#14345d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0b1f3a]">Edit PO draft</a>
                <form method="POST" action="{{ route('admin.po.status', $po) }}" onsubmit="return window.confirm('Proses PO ini? Stok belum berubah. Stok fisik berkurang saat Surat Jalan pengiriman diterbitkan.')">
                    @csrf
                    @method('PATCH')
                    <input type="hidden" name="status" value="diproses">
                    <button type="submit" class="inline-flex min-h-11 items-center rounded-lg bg-red-600 px-5 text-sm font-bold text-white transition hover:bg-red-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">Proses PO</button>
                </form>
                <form method="POST" action="{{ route('admin.po.status', $po) }}" onsubmit="return window.confirm('Batalkan PO draft ini?')">
                    @csrf
                    @method('PATCH')
                    <input type="hidden" name="status" value="batal">
                    <button type="submit" class="inline-flex min-h-11 items-center rounded-lg border border-red-300 px-5 text-sm font-bold text-red-700 transition hover:bg-red-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">Batalkan</button>
                </form>
            </section>
        @elseif ($po->status === \App\Models\Po::STATUS_DIPROSES)
            <section class="flex flex-wrap gap-3 rounded-2xl border border-yellow-200 bg-yellow-50 p-5" aria-label="Aksi PO diproses">
                <a href="{{ route('admin.surat-jalan.create', $po) }}" class="inline-flex min-h-11 items-center rounded-lg bg-red-600 px-5 text-sm font-bold text-white transition hover:bg-red-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">Buat Surat Jalan</a>
                <form method="POST" action="{{ route('admin.po.status', $po) }}">
                    @csrf
                    @method('PATCH')
                    <input type="hidden" name="status" value="selesai">
                    <button type="submit" class="inline-flex min-h-11 items-center rounded-lg bg-[#0b1f3a] px-5 text-sm font-bold text-white transition hover:bg-[#14345d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0b1f3a]">Tandai selesai</button>
                </form>
                @if ($po->hasActiveSuratJalan())
                    <p class="inline-flex min-h-11 items-center rounded-lg border border-slate-300 px-4 text-sm font-semibold text-slate-600">Batalkan PO setelah Surat Jalan aktif dibatalkan.</p>
                @else
                    <form method="POST" action="{{ route('admin.po.status', $po) }}" onsubmit="return window.confirm('Batalkan PO ini? Stok tidak berubah karena pengurangan stok dilakukan saat Surat Jalan diterbitkan.')">
                        @csrf
                        @method('PATCH')
                        <input type="hidden" name="status" value="batal">
                        <button type="submit" class="inline-flex min-h-11 items-center rounded-lg border border-red-300 px-5 text-sm font-bold text-red-700 transition hover:bg-red-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">Batalkan PO</button>
                    </form>
                @endif
            </section>
        @endif

        <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm" aria-labelledby="po-items-title">
            <div class="border-b border-slate-200 p-5 sm:p-7"><p class="text-sm font-bold uppercase tracking-[0.15em] text-red-600">Isi pesanan</p><h2 id="po-items-title" class="mt-2 text-xl font-black text-[#0b1f3a]">Rincian item</h2></div>
            <div class="overflow-x-auto">
                <table class="w-full min-w-[640px] text-left text-sm">
                    <caption class="sr-only">Rincian item Purchase Order</caption>
                    <thead class="bg-[#0b1f3a] text-xs uppercase tracking-[0.12em] text-slate-200"><tr><th class="px-5 py-4 font-bold">Item</th><th class="px-5 py-4 text-center font-bold">Tipe</th><th class="px-5 py-4 text-center font-bold">Qty</th><th class="px-5 py-4 text-right font-bold">Harga</th><th class="px-5 py-4 text-right font-bold">Jumlah</th></tr></thead>
                    <tbody class="divide-y divide-slate-100">
                        @forelse ($po->details as $detail)
                            <tr><td class="px-5 py-4"><p class="font-bold text-slate-900">{{ $detail->nama_barang }}</p><p class="mt-1 text-xs text-slate-500">{{ $detail->unit ?: 'Unit tidak diisi' }}</p></td><td class="px-5 py-4 text-center"><span class="inline-flex rounded-full px-3 py-1 text-xs font-bold {{ $detail->barangJasa?->tipe === 'jasa' ? 'bg-slate-100 text-slate-700' : 'bg-yellow-100 text-yellow-900' }}">{{ ucfirst($detail->barangJasa?->tipe ?? 'snapshot') }}</span></td><td class="px-5 py-4 text-center text-slate-700">{{ $detail->qty }}</td><td class="px-5 py-4 text-right text-slate-700">Rp {{ number_format((float) $detail->harga_satuan, 0, ',', '.') }}</td><td class="px-5 py-4 text-right font-bold text-slate-900">Rp {{ number_format((float) $detail->amount, 0, ',', '.') }}</td></tr>
                        @empty
                            <tr><td colspan="5" class="px-5 py-10 text-center text-sm text-slate-500">Belum ada item pada PO ini.</td></tr>
                        @endforelse
                    </tbody>
                    <tfoot class="bg-slate-50 text-sm"><tr><td colspan="4" class="px-5 py-2 text-right text-slate-500">Subtotal</td><td class="px-5 py-2 text-right font-bold">Rp {{ number_format((float) $po->subtotal, 0, ',', '.') }}</td></tr><tr><td colspan="4" class="px-5 py-2 text-right text-slate-500">Diskon</td><td class="px-5 py-2 text-right font-bold">-Rp {{ number_format((float) $po->diskon, 0, ',', '.') }}</td></tr><tr><td colspan="4" class="px-5 py-2 text-right text-slate-500">PPN</td><td class="px-5 py-2 text-right font-bold">Rp {{ number_format((float) $po->ppn, 0, ',', '.') }}</td></tr><tr class="text-base"><td colspan="4" class="px-5 py-3 text-right font-black text-[#0b1f3a]">Total</td><td class="px-5 py-3 text-right font-black text-[#0b1f3a]">Rp {{ number_format((float) $po->total, 0, ',', '.') }}</td></tr></tfoot>
                </table>
            </div>
        </section>

        <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7" aria-labelledby="po-surat-jalan-title">
            <div class="flex flex-wrap items-start justify-between gap-4">
                <div><p class="text-sm font-bold uppercase tracking-[0.15em] text-red-600">Dokumen pengiriman</p><h2 id="po-surat-jalan-title" class="mt-2 text-xl font-black text-[#0b1f3a]">Surat Jalan</h2></div>
                @if ($po->canCreateSuratJalan())
                    <a href="{{ route('admin.surat-jalan.create', $po) }}" class="inline-flex min-h-11 items-center rounded-lg bg-red-600 px-4 text-sm font-bold text-white hover:bg-red-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">Buat Surat Jalan</a>
                @endif
            </div>
            <p class="mt-2 text-sm leading-6 text-slate-600">Stok fisik berkurang saat Surat Jalan jenis Pengiriman diterbitkan, bukan saat PO diproses.</p>
            @if ($po->suratJalans->isEmpty())
                <p class="mt-5 text-sm leading-6 text-slate-600">Belum ada Surat Jalan untuk PO ini.</p>
            @else
                <div class="mt-5 space-y-3">
                    @foreach ($po->suratJalans as $suratJalan)
                        <a href="{{ route('admin.surat-jalan.show', $suratJalan) }}" class="block rounded-xl border border-slate-200 p-4 hover:border-[#0b1f3a] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0b1f3a]"><div class="flex flex-wrap items-center justify-between gap-3"><span class="font-mono text-sm font-bold text-[#0b1f3a]">{{ $suratJalan->nosuratjalan }}</span><span class="inline-flex rounded-full px-3 py-1 text-xs font-bold {{ $suratJalan->status_class }}">{{ $suratJalan->label_status }}</span></div><p class="mt-2 text-sm text-slate-600">{{ $suratJalan->label_jenis }} - {{ $suratJalan->tgl?->translatedFormat('d F Y') }}</p></a>
                    @endforeach
                </div>
            @endif
        </section>

        <section class="grid gap-6 lg:grid-cols-2">
            <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><p class="text-sm font-bold uppercase tracking-[0.15em] text-red-600">Riwayat status</p><h2 class="mt-2 text-xl font-black text-[#0b1f3a]">Jejak dokumen</h2><ol class="mt-5 space-y-4 border-l-2 border-yellow-300 pl-5"><li><p class="font-bold text-slate-800">Draft dibuat</p><p class="mt-1 text-xs text-slate-500">{{ $po->created_at?->timezone('Asia/Jakarta')->translatedFormat('d F Y, H:i') }} WIB</p></li><li><p class="font-bold text-slate-800">Status terakhir: {{ $po->label_status }}</p><p class="mt-1 text-xs text-slate-500">Diperbarui {{ $po->updated_at?->timezone('Asia/Jakarta')->translatedFormat('d F Y, H:i') }} WIB</p></li></ol></div>
            <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div class="flex flex-wrap items-start justify-between gap-4"><div><p class="text-sm font-bold uppercase tracking-[0.15em] text-red-600">Pelaksanaan jasa</p><h2 class="mt-2 text-xl font-black text-[#0b1f3a]">Work Order</h2></div>@if ($po->canCreateWorkOrder())<a href="{{ route('admin.work-order.create', $po) }}" class="inline-flex min-h-11 items-center rounded-lg bg-red-600 px-4 text-sm font-bold text-white hover:bg-red-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600">Buat Work Order</a>@endif</div>@if ($po->workOrders->isEmpty())<p class="mt-5 text-sm leading-6 text-slate-600">Belum ada Work Order untuk PO ini. Tombol akan tersedia saat PO berstatus Diproses atau Selesai.</p>@else<div class="mt-5 space-y-3">@foreach ($po->workOrders as $workOrder)<a href="{{ route('admin.work-order.show', $workOrder) }}" class="block rounded-xl border border-slate-200 p-4 hover:border-[#0b1f3a] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0b1f3a]"><div class="flex flex-wrap items-center justify-between gap-3"><span class="font-mono text-sm font-bold text-[#0b1f3a]">{{ $workOrder->nomor_wo }}</span><span class="inline-flex rounded-full px-3 py-1 text-xs font-bold {{ $workOrder->status_class }}">{{ $workOrder->label_status }}</span></div><p class="mt-2 text-sm text-slate-600">{{ $workOrder->petugas?->namapetugas ? 'Teknisi: '.$workOrder->petugas->namapetugas : 'Belum ditugaskan' }}</p></a>@endforeach</div>@endif</div>
        </section>

        @if ($po->catatan)
            <section class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 class="text-xl font-black text-[#0b1f3a]">Catatan</h2><p class="mt-3 whitespace-pre-line text-sm leading-7 text-slate-700">{{ $po->catatan }}</p></section>
        @endif
    </div>
@endsection
